import { supabase } from './supabase';

// ===== COURSES =====
export async function getCourses(userId: string) {
  const { data, error } = await supabase
    .from('courses')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

export async function addCourse(course: {
  user_id: string;
  name: string;
  code: string;
  credits: number;
  category: string;
  status: string;
}) {
  const { data, error } = await supabase
    .from('courses')
    .insert(course)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateCourse(id: string, updates: Partial<{
  name: string;
  code: string;
  credits: number;
  category: string;
  status: string;
  grade: string;
}>) {
  const { data, error } = await supabase
    .from('courses')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function deleteCourse(id: string) {
  const { error } = await supabase
    .from('courses')
    .delete()
    .eq('id', id);

  if (error) throw error;
}

// ===== TASKS =====
export async function getTasks(userId: string) {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .eq('user_id', userId)
    .order('due_date', { ascending: true });

  if (error) throw error;
  return data;
}

export async function addTask(task: {
  user_id: string;
  title: string;
  type: string;
  status: string;
  priority: string;
  due_date?: string;
  course_code?: string;
}) {
  const { data, error } = await supabase
    .from('tasks')
    .insert(task)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateTask(id: string, updates: Partial<{
  status: string;
  priority: string;
  due_date: string;
}>) {
  const { data, error } = await supabase
    .from('tasks')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function deleteTask(id: string) {
  const { error } = await supabase
    .from('tasks')
    .delete()
    .eq('id', id);

  if (error) throw error;
}

// ===== NOTES =====
export async function getNotesByCourse(userId: string, courseCode: string) {
  const { data, error } = await supabase
    .from('notes')
    .select('*')
    .eq('user_id', userId)
    .eq('course_code', courseCode)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data ?? [];
}

export async function addNote(note: {
  user_id: string;
  course_code: string;
  title: string;
  content: string;
  tags: string[];
  link: string | null;
}) {
  const { data, error } = await supabase
    .from('notes')
    .insert({
      ...note,
      created_date: new Date().toISOString().split('T')[0],
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function deleteNote(id: string) {
  const { error } = await supabase
    .from('notes')
    .delete()
    .eq('id', id);

  if (error) throw error;
}

// ===== DASHBOARD =====
export async function getDashboardStats(userId: string) {
  // نجلب المواد والمهام بشكل متوازٍ
  const [coursesRes, tasksRes] = await Promise.all([
    supabase.from('courses').select('id, status, credits, grade').eq('user_id', userId),
    supabase.from('tasks').select('id, status, priority, due_date, title, type, course_code').eq('user_id', userId),
  ]);

  if (coursesRes.error) throw coursesRes.error;
  if (tasksRes.error) throw tasksRes.error;

  const courses = coursesRes.data ?? [];
  const tasks = tasksRes.data ?? [];

  const completedCourses = courses.filter(c => c.status === 'مكتملة');
  const activeCourses = courses.filter(c => c.status === 'قيد الدراسة');
  const completedCredits = completedCourses.reduce((sum, c) => sum + (c.credits ?? 0), 0);
  const totalCredits = courses.reduce((sum, c) => sum + (c.credits ?? 0), 0);
  const progressPercent = totalCredits > 0 ? Math.round((completedCredits / totalCredits) * 100) : 0;

  const pendingTasks = tasks.filter(t => t.status === 'pending' || t.status === 'قيد الانتظار');
  const now = Date.now();
  const in48h = now + 48 * 60 * 60 * 1000;
  const urgentTasks = tasks.filter(t => {
    if (t.priority !== 'عالي' && t.priority !== 'high') return false;
    if (t.status === 'done' || t.status === 'مكتمل') return false;
    if (!t.due_date) return false;
    const due = new Date(t.due_date).getTime();
    return due <= in48h;
  });

  // المهام القادمة (خلال 7 أيام)
  const in7d = now + 7 * 24 * 60 * 60 * 1000;
  const upcomingTasks = tasks
    .filter(t => {
      if (t.status === 'done' || t.status === 'مكتمل') return false;
      if (!t.due_date) return false;
      const due = new Date(t.due_date).getTime();
      return due >= now && due <= in7d;
    })
    .sort((a, b) => new Date(a.due_date!).getTime() - new Date(b.due_date!).getTime())
    .slice(0, 5);

  // أقرب امتحان
  const nextExam = tasks
    .filter(t => (t.type === 'امتحان' || t.type === 'exam') && t.status !== 'done' && t.due_date)
    .sort((a, b) => new Date(a.due_date!).getTime() - new Date(b.due_date!).getTime())[0];

  const daysToExam = nextExam?.due_date
    ? Math.max(0, Math.ceil((new Date(nextExam.due_date).getTime() - now) / (1000 * 60 * 60 * 24)))
    : null;

  return {
    completedCredits,
    totalCredits,
    completedCourses: completedCourses.length,
    activeCourses,
    progressPercent,
    pendingTasksCount: pendingTasks.length,
    urgentTasks,
    upcomingTasks,
    daysToExam,
    nextExamTitle: nextExam?.title ?? null,
  };
}

// ===== PROFILE =====
export const getProfile = async (userId: string) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();
  return { data, error };
};

export const updateProfile = async (userId: string, updates: {
  full_name?: string;
  university?: string;
  major?: string;
  semester?: string;
  total_credits?: number;
  onboarded?: boolean;
  degree_type?: string; // ✅ هاد كان ناقص
}) => {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId);
  return { data, error };
};
// ===== DASHBOARD HELPERS =====
export async function getAcademicProgress(userId: string) {
  const { data, error } = await supabase
    .from('courses')
    .select('status, credits, grade')
    .eq('user_id', userId);

  if (error) throw error;

  const courses = data ?? [];
  const totalCredits = courses.reduce((s: number, c: {credits: number}) => s + (c.credits || 0), 0);
  const completedCredits = courses
    .filter((c: {status: string}) => c.status === 'مكتملة')
    .reduce((s: number, c: {credits: number}) => s + (c.credits || 0), 0);
  const completionPercentage = totalCredits > 0
    ? Math.round((completedCredits / totalCredits) * 100)
    : 0;

  return { totalCredits, completedCredits, completionPercentage };
}

export async function getCurrentCourses(userId: string) {
  const { data, error } = await supabase
    .from('courses')
    .select('*')
    .eq('user_id', userId)
    .eq('status', 'قيد الدراسة')
    .limit(5);

  if (error) throw error;
  return data ?? [];
}

export async function getUrgentTasks(userId: string) {
  const now = new Date();
  const in48h = new Date(now.getTime() + 48 * 60 * 60 * 1000)
    .toISOString()
    .split('T')[0];

  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .eq('user_id', userId)
    .eq('priority', 'عالية')
    .neq('status', 'مكتملة')
    .lte('due_date', in48h)
    .order('due_date', { ascending: true })
    .limit(5);

  if (error) throw error;
  return data ?? [];
}

export async function updateTaskStatus(id: string, status: string) {
  const { data, error } = await supabase
    .from('tasks')
    .update({ status })
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}