'use client';

/**
 * useAuth Hook
 * ========================
 * إعادة التصدير من AuthContext
 * هذا يضمن Single Source of Truth - بدون تكرار subscription
 */

import { useAuth as useAuthContext } from '@/lib/context/AuthContext';

// إعادة التصدير مع توحيد الأسماء
export function useAuth() {
  const context = useAuthContext();

  return {
    user: context.user,
    loading: context.isLoadingAuth,  // توحيد الاسم مع الملف القديم
    isAuthenticated: context.isAuthenticated,
    logout: context.logout,
  };
}