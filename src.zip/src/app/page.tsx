'use client';

import { useAuth } from '@/lib/hooks/useAuth';
import { useDashboardData } from '@/lib/hooks/useDashboardData';
import LandingPage from '@/components/landing/LandingPage';
import WelcomeCard from '@/components/dashboard/WelcomeCard';
import StatsGrid from '@/components/dashboard/StatsGrid';
import QuickFeatures from '@/components/dashboard/QuickFeatures';
import ProgressCard from '@/components/dashboard/ProgressCard';
import CurrentCourses from '@/components/dashboard/CurrentCourses';
import UpcomingTasks from '@/components/dashboard/UpcomingTasks';
import QuickStats from '@/components/dashboard/QuickStats';
import UrgentTasksAlert from '@/components/dashboard/UrgentTasksAlert';

export default function HomePage() {
  const { user } = useAuth();

  // مش مسجّل — Landing Page
  if (!user) return <LandingPage />;

  // Dashboard
  return <Dashboard user={user} />;
}

function Dashboard({
  user,
}: {
  user: { user_metadata?: { full_name?: string } };
}) {
  const {
    stats,
    progress,
    currentCourses,
    urgentTasks,
    upcomingTasks,
    loading,
    markTaskDone,
    postponeTask,
  } = useDashboardData();

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <WelcomeCard
        user={{ full_name: user.user_metadata?.full_name || 'مستخدم' }}
      />

      <UrgentTasksAlert
        tasks={urgentTasks}
        onMarkDone={markTaskDone}
        onPostpone={postponeTask}
      />

      <StatsGrid loading={loading} />
      <QuickFeatures />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <QuickStats
            activeCourses={stats?.activeCourses}
            pendingTasks={stats?.pendingTasks}
            daysToExam={stats?.daysToExam}
            loading={loading}
          />
          <ProgressCard
            percent={progress?.percent}
            completedCredits={progress?.completedCredits}
            totalCredits={progress?.totalCredits}
            loading={loading}
          />
          <CurrentCourses courses={currentCourses} loading={loading} />
        </div>
        <div className="space-y-6">
          <UpcomingTasks tasks={upcomingTasks} loading={loading} />
        </div>
      </div>
    </div>
  );
}