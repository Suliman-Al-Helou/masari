import { ClassroomTasksView } from "@/components/classroom/ClassroomTasksView";

export default function ClassroomPage() {
  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 sm:px-6 lg:px-8">
      <ClassroomTasksView />
    </main>
  );
}