"use client";

import {
  useEffect,
  useMemo,
  useState,
} from "react";

import type {
  LocalClassroomTask,
  LocalClassroomTasksData,
  LocalClassroomTaskStatus,
} from "@/features/integrations/google-classroom/types";

type TaskFilter =
  | "all"
  | LocalClassroomTaskStatus;

type TasksApiResponse =
  | {
      success: true;
      source: "supabase";
      data: LocalClassroomTasksData;
    }
  | {
      success: false;
      code?: string;
      error: string;
    };

const FILTERS: Array<{
  value: TaskFilter;
  label: string;
}> = [
  {
    value: "all",
    label: "الكل",
  },
  {
    value: "upcoming",
    label: "قادمة",
  },
  {
    value: "overdue",
    label: "متأخرة",
  },
  {
    value: "submitted",
    label: "مسلّمة",
  },
  {
    value: "returned",
    label: "مصححة",
  },
  {
    value: "no_due_date",
    label: "بلا موعد",
  },
];

const STATUS_LABELS: Record<
  LocalClassroomTaskStatus,
  string
> = {
  upcoming: "قادمة",
  overdue: "متأخرة",
  submitted: "مسلّمة",
  returned: "مصححة",
  no_due_date: "بلا موعد",
};

function formatDueDate(
  value: string | null,
): string {
  if (!value) {
    return "لا يوجد موعد تسليم";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "موعد غير معروف";
  }

  return new Intl.DateTimeFormat("ar-PS", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Asia/Gaza",
  }).format(date);
}

function getStatusClasses(
  status: LocalClassroomTaskStatus,
): string {
  switch (status) {
    case "overdue":
      return "bg-red-50 text-red-700 ring-red-200";

    case "upcoming":
      return "bg-blue-50 text-blue-700 ring-blue-200";

    case "submitted":
      return "bg-green-50 text-green-700 ring-green-200";

    case "returned":
      return "bg-purple-50 text-purple-700 ring-purple-200";

    case "no_due_date":
      return "bg-slate-100 text-slate-700 ring-slate-200";
  }
}

function TaskCard({
  task,
}: {
  task: LocalClassroomTask;
}) {
  return (
    <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-violet-700">
            {task.course.name}
          </p>

          <h2 className="mt-1 text-lg font-bold text-slate-900">
            {task.title}
          </h2>
        </div>

        <span
          className={[
            "rounded-full px-3 py-1 text-xs font-semibold ring-1 ring-inset",
            getStatusClasses(task.status),
          ].join(" ")}
        >
          {STATUS_LABELS[task.status]}
        </span>
      </div>

      {task.description ? (
        <p className="mt-3 max-h-20 overflow-hidden whitespace-pre-line text-sm leading-6 text-slate-600">
          {task.description}
        </p>
      ) : null}

      <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-sm text-slate-600">
        <span>
          الموعد: {formatDueDate(task.dueAt)}
        </span>

        {task.maxPoints !== null ? (
          <span>
            العلامة: {task.maxPoints}
          </span>
        ) : null}

        {task.submission?.late ? (
          <span className="font-medium text-red-600">
            تم التسليم متأخرًا
          </span>
        ) : null}
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        {task.alternateLink ? (
          <a
            href={task.alternateLink}
            target="_blank"
            rel="noreferrer"
            className="inline-flex min-h-10 items-center justify-center rounded-lg bg-violet-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-violet-700 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:ring-offset-2"
          >
            فتح في Google Classroom
          </a>
        ) : (
          <span className="text-sm text-slate-500">
            رابط المهمة غير متوفر
          </span>
        )}
      </div>
    </article>
  );
}

function TasksSkeleton() {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      {Array.from({
        length: 4,
      }).map((_, index) => (
        <div
          key={index}
          className="h-56 animate-pulse rounded-2xl border border-slate-200 bg-slate-100"
        />
      ))}
    </div>
  );
}

export function ClassroomTasksView() {
  const [data, setData] =
    useState<LocalClassroomTasksData | null>(
      null,
    );

  const [filter, setFilter] =
    useState<TaskFilter>("all");

  const [isLoading, setIsLoading] =
    useState(true);

  const [error, setError] =
    useState<string | null>(null);

  const [reloadKey, setReloadKey] =
    useState(0);

  useEffect(() => {
    const controller = new AbortController();

    async function loadTasks() {
      setIsLoading(true);
      setError(null);

      try {
        const response = await fetch(
          "/api/integrations/google-classroom/tasks?limit=200",
          {
            signal: controller.signal,
            headers: {
              Accept: "application/json",
            },
          },
        );

        const body =
          (await response.json()) as TasksApiResponse;

        if (!response.ok || !body.success) {
          throw new Error(
            body.success
              ? "تعذر تحميل المهام"
              : body.error,
          );
        }

        setData(body.data);
      } catch (loadError) {
        if (
          loadError instanceof DOMException &&
          loadError.name === "AbortError"
        ) {
          return;
        }

        setError(
          loadError instanceof Error
            ? loadError.message
            : "تعذر تحميل المهام",
        );
      } finally {
        if (!controller.signal.aborted) {
          setIsLoading(false);
        }
      }
    }

    void loadTasks();

    return () => {
      controller.abort();
    };
  }, [reloadKey]);

  const filteredTasks = useMemo(() => {
    if (!data) {
      return [];
    }

    if (filter === "all") {
      return data.tasks;
    }

    return data.tasks.filter(
      (task) => task.status === filter,
    );
  }, [data, filter]);

  function getFilterCount(
    value: TaskFilter,
  ): number {
    if (!data) {
      return 0;
    }

    switch (value) {
      case "all":
        return data.summary.total;

      case "upcoming":
        return data.summary.upcoming;

      case "overdue":
        return data.summary.overdue;

      case "submitted":
        return data.summary.submitted;

      case "returned":
        return data.summary.returned;

      case "no_due_date":
        return data.summary.noDueDate;
    }
  }

  return (
    <section
      dir="rtl"
      className="mx-auto w-full max-w-7xl space-y-6"
    >
      <header>
        <h1 className="text-2xl font-bold text-slate-950">
          مهام Google Classroom
        </h1>

        <p className="mt-2 text-sm text-slate-600">
          تابع المهام القادمة والمتأخرة والمسلّمة
          من مكان واحد.
        </p>
      </header>

      <div className="flex flex-wrap gap-2">
        {FILTERS.map((item) => {
          const isActive =
            filter === item.value;

          return (
            <button
              key={item.value}
              type="button"
              onClick={() =>
                setFilter(item.value)
              }
              aria-pressed={isActive}
              className={[
                "rounded-full px-4 py-2 text-sm font-medium transition",
                isActive
                  ? "bg-violet-600 text-white"
                  : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
              ].join(" ")}
            >
              {item.label}{" "}
              <span className="opacity-75">
                ({getFilterCount(item.value)})
              </span>
            </button>
          );
        })}
      </div>

      {isLoading ? <TasksSkeleton /> : null}

      {!isLoading && error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 p-5">
          <p className="font-medium text-red-800">
            {error}
          </p>

          <button
            type="button"
            onClick={() =>
              setReloadKey(
                (current) => current + 1,
              )
            }
            className="mt-4 rounded-lg bg-red-700 px-4 py-2 text-sm font-semibold text-white"
          >
            إعادة المحاولة
          </button>
        </div>
      ) : null}

      {!isLoading &&
      !error &&
      filteredTasks.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center">
          <p className="font-medium text-slate-800">
            لا توجد مهام ضمن هذا التصنيف.
          </p>
        </div>
      ) : null}

      {!isLoading &&
      !error &&
      filteredTasks.length > 0 ? (
        <div className="grid gap-4 lg:grid-cols-2">
          {filteredTasks.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
            />
          ))}
        </div>
      ) : null}
    </section>
  );
}