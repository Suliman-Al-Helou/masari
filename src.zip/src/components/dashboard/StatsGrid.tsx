import { GraduationCap, BookOpen, Users } from 'lucide-react';

interface StatsGridProps {
  loading?: boolean;
}

export default function StatsGrid({ loading }: StatsGridProps) {
  // Skeleton أثناء التحميل
  if (loading) {
    return (
      <div className="grid grid-cols-3 gap-3">
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="rounded-2xl border p-4 text-center animate-pulse"
          >
            <div className="w-5 h-5 mx-auto mb-2 bg-muted rounded" />
            <div className="h-8 bg-muted rounded mb-1" />
            <div className="h-3 bg-muted rounded w-16 mx-auto" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-3 gap-3">
      <div className="rounded-2xl border p-4 text-center bg-emerald-50 text-emerald-600 border-emerald-200">
        <GraduationCap className="w-5 h-5 mx-auto mb-2 opacity-70" />
        <p className="text-2xl font-bold">GPA</p>
        <p className="text-xs mt-1 opacity-70">معدلك التراكمي</p>
      </div>
      <div className="rounded-2xl border p-4 text-center bg-blue-50 text-blue-600 border-blue-200">
        <BookOpen className="w-5 h-5 mx-auto mb-2 opacity-70" />
        <p className="text-2xl font-bold">منهاج</p>
        <p className="text-xs mt-1 opacity-70">الخطة الدراسية</p>
      </div>
      <div className="rounded-2xl border p-4 text-center bg-purple-50 text-purple-600 border-purple-200">
        <Users className="w-5 h-5 mx-auto mb-2 opacity-70" />
        <p className="text-2xl font-bold">زملاء</p>
        <p className="text-xs mt-1 opacity-70">شبكتك</p>
      </div>
    </div>
  );
}