import { BookOpen, Target, Calendar } from 'lucide-react';

interface QuickStatsProps {
  activeCourses?: number | null;
  pendingTasks?: number | null;
  daysToExam?: number | null;
  loading?: boolean;
}

export default function QuickStats({
  activeCourses,
  pendingTasks,
  daysToExam,
  loading,
}: QuickStatsProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-3 gap-3">
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="rounded-2xl bg-card border border-border/50 p-4 text-center animate-pulse"
          >
            <div className="w-10 h-10 rounded-xl bg-muted mx-auto mb-2" />
            <div className="h-8 bg-muted rounded mb-1" />
            <div className="h-3 bg-muted rounded w-20 mx-auto" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-3 gap-3">
      <div className="rounded-2xl bg-card border border-border/50 p-4 text-center">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-2">
          <BookOpen className="w-5 h-5 text-primary" />
        </div>
        <p className="text-2xl font-bold text-foreground">
          {activeCourses ?? 0}
        </p>
        <p className="text-[11px] text-muted-foreground mt-1">مادة مسجلة</p>
      </div>
      <div className="rounded-2xl bg-card border border-border/50 p-4 text-center">
        <div className="w-10 h-10 rounded-xl bg-warning/10 flex items-center justify-center mx-auto mb-2">
          <Target className="w-5 h-5 text-warning" />
        </div>
        <p className="text-2xl font-bold text-foreground">
          {pendingTasks ?? 0}
        </p>
        <p className="text-[11px] text-muted-foreground mt-1">واجبات معلقة</p>
      </div>
      <div className="rounded-2xl bg-card border border-border/50 p-4 text-center">
        <div className="w-10 h-10 rounded-xl bg-info/10 flex items-center justify-center mx-auto mb-2">
          <Calendar className="w-5 h-5 text-info" />
        </div>
        <p className="text-2xl font-bold text-foreground">
          {daysToExam ?? '—'}
        </p>
        <p className="text-[11px] text-muted-foreground mt-1">يوم للامتحان</p>
      </div>
    </div>
  );
}