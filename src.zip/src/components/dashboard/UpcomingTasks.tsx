import { Clock, FileText, Code, CheckCircle, FileCheck } from 'lucide-react';

interface UpcomingTask {
  id: string;
  title: string;
  type: string;
  course_code?: string;
  status: string;
  priority: string;
  due_date?: string;
}

interface UpcomingTasksProps {
  tasks?: UpcomingTask[];
  loading?: boolean;
}

// خريطة الأيقونات حسب نوع المهمة
const TYPE_ICONS: Record<string, React.ElementType> = {
  'واجب': FileText,
  'مشروع': Code,
  'امتحان': CheckCircle,
  default: FileCheck,
};

export default function UpcomingTasks({ tasks = [], loading }: UpcomingTasksProps) {
  if (loading) {
    return (
      <div className="rounded-2xl bg-card border border-border/50 p-5 animate-pulse">
        <div className="flex items-center justify-between mb-4">
          <div className="h-6 bg-muted rounded w-32" />
          <div className="h-5 bg-muted rounded w-20" />
        </div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
              <div className="w-9 h-9 rounded-lg bg-muted" />
              <div className="flex-1">
                <div className="h-4 bg-muted rounded w-3/4 mb-1" />
                <div className="h-3 bg-muted rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (tasks.length === 0) {
    return (
      <div className="rounded-2xl bg-card border border-border/50 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-foreground">المهام القادمة</h3>
          <span className="flex items-center gap-1 text-xs bg-muted text-muted-foreground px-3 py-1 rounded-lg">
            <Clock className="w-3 h-3" />
            هذا الأسبوع
          </span>
        </div>
        <p className="text-sm text-muted-foreground text-center py-8">
          لا توجد مهام قادمة
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-card border border-border/50 p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-foreground">المهام القادمة</h3>
        <span className="flex items-center gap-1 text-xs bg-muted text-muted-foreground px-3 py-1 rounded-lg">
          <Clock className="w-3 h-3" />
          هذا الأسبوع
        </span>
      </div>

      <div className="space-y-3">
        {tasks.map((task) => {
          const Icon = TYPE_ICONS[task.type] || TYPE_ICONS.default;
          const isUrgent = task.priority === 'عالي';

          return (
            <div
              key={task.id}
              className="flex items-center gap-3 p-3 rounded-xl bg-muted/50 hover:bg-muted transition-colors"
            >
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                isUrgent
                  ? 'bg-destructive/10 text-destructive'
                  : 'bg-primary/10 text-primary'
              }`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">{task.title}</p>
                <p className="text-xs text-muted-foreground">{task.course_code || '—'}</p>
              </div>
              <span className="text-[10px] border border-border rounded-lg px-2 py-1 shrink-0 text-muted-foreground">
                {task.type}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}