import { TrendingUp } from 'lucide-react';

interface ProgressCardProps {
  percent?: number | null;
  completedCredits?: number | null;
  totalCredits?: number | null;
  loading?: boolean;
}

export default function ProgressCard({
  percent,
  completedCredits,
  totalCredits,
  loading,
}: ProgressCardProps) {
  if (loading) {
    return (
      <div className="rounded-2xl bg-card border border-border/50 p-5 animate-pulse">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-muted" />
            <div className="h-5 bg-muted rounded w-32" />
          </div>
          <div className="h-5 bg-muted rounded w-12" />
        </div>
        <div className="h-3 bg-muted rounded-full" />
      </div>
    );
  }

  const displayPercent = percent ?? 0;
  const displayCompleted = completedCredits ?? 0;
  const displayTotal = totalCredits ?? 0;

  return (
    <div className="rounded-2xl bg-card border border-border/50 p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-warning/10 flex items-center justify-center">
            <TrendingUp className="w-4 h-4 text-warning" />
          </div>
          <h3 className="font-bold text-foreground">تقدمك في المسار</h3>
        </div>
        <span className="text-sm font-bold text-primary">{displayPercent}%</span>
      </div>

      {/* Progress bar */}
      <div className="h-3 bg-muted rounded-full overflow-hidden">
        <div
          className="h-full bg-primary rounded-full transition-all duration-500"
          style={{ width: `${displayPercent}%` }}
        />
      </div>

      <div className="flex items-center justify-between mt-3">
        <span className="text-xs text-muted-foreground">
          {displayCompleted} / {displayTotal} ساعة مكتملة
        </span>
        <span className="text-xs text-muted-foreground">{displayPercent}% مكتمل</span>
      </div>
    </div>
  );
}