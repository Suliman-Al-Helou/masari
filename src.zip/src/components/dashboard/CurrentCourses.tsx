import Link from 'next/link';

interface CurrentCourse {
  id: string;
  name: string;
  code: string;
  credits: number;
  category: string;
}

interface CurrentCoursesProps {
  courses?: CurrentCourse[];
  loading?: boolean;
}

// ألوان عشوائية للمجالات
const CATEGORY_COLORS: Record<string, string> = {
  'متطلب تخصص': 'bg-primary text-primary-foreground',
  'متطلب جامعة': 'bg-info text-info-foreground',
  'متطلب كلية': 'bg-warning text-warning-foreground',
  'اختياري': 'bg-success text-success-foreground',
  default: 'bg-secondary text-secondary-foreground',
};

export default function CurrentCourses({ courses = [], loading }: CurrentCoursesProps) {
  if (loading) {
    return (
      <div className="rounded-2xl bg-card border border-border/50 p-5 animate-pulse">
        <div className="h-6 bg-muted rounded w-32 mb-4" />
        <div className="flex flex-wrap gap-2">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-8 bg-muted rounded-xl w-24" />
          ))}
        </div>
      </div>
    );
  }

  if (courses.length === 0) {
    return (
      <div className="rounded-2xl bg-card border border-border/50 p-5">
        <h3 className="font-bold text-foreground mb-4">المواد الحالية</h3>
        <p className="text-sm text-muted-foreground text-center py-4">
          لا توجد مواد قيد الدراسة حالياً
        </p>
        <Link
          href="/academic-path"
          className="block text-center text-sm text-primary hover:underline"
        >
          أضف موادك الأولى
        </Link>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-card border border-border/50 p-5">
      <h3 className="font-bold text-foreground mb-4">المواد الحالية</h3>
      <div className="flex flex-wrap gap-2">
        {courses.map((course) => (
          <Link
            key={course.id}
            href={`/academic-path?course=${course.id}`}
            className={`${CATEGORY_COLORS[course.category] || CATEGORY_COLORS.default} px-4 py-2 rounded-xl text-xs font-medium cursor-pointer hover:opacity-90 transition-opacity`}
          >
            {course.name}
          </Link>
        ))}
      </div>
    </div>
  );
}