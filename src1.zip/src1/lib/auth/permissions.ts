export const PERMISSION = {
  USERS_MANAGE: "users:manage",
  DOCTORS_MANAGE: "doctors:manage",
  REVIEWS_MODERATE: "reviews:moderate",
} as const;

export type Permission = (typeof PERMISSION)[keyof typeof PERMISSION];

export type Role = "student" | "admin";

const ROLE_PERMISSIONS: Record<Role, readonly Permission[]> = {
  student: [],
  admin: [
    PERMISSION.REVIEWS_MODERATE,
    PERMISSION.DOCTORS_MANAGE,
    PERMISSION.REVIEWS_MODERATE,
  ],
};

export function can(role: Role, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role].includes(permission);
}
